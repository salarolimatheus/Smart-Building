# Detector de Presenca utilizando BLE
Sistema embarcado para detector de presença utilizando Bluetooth Low Energy com o microcontrolador ESP32 na plataforma NodeMCU.
